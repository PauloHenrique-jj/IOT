/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reservadesalas;

/**
 *
 * @author devmat
 */
public class ReservaDeSalas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
